Vinaya: Notes on the Bhikkhu Pātimokkha

sajjhaya-vinaya.md is the whole book in one file.
sections/ holds the same text split into one file per section or rule, in reading order; each carries its own footnotes.
Licence: CC BY-NC-SA 4.0 (see the LICENSE in the release).
