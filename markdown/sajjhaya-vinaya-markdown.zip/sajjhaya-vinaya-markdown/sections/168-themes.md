# Themes

Some threads run through the rules without belonging to any one character. A concern shows itself in one origin story, returns in another class of rules under another penalty, and is taken up again in the suttas that stand beside them. The pieces that follow take those threads in the order the book first meets them. Each follows the rules where the thread runs and ends with the rules it draws on, as the character pieces do.


