# Sources and Abbreviations

The footnotes name their sources briefly, and this page is the key to them. Each source is given once here: who wrote it, what it is, and how the footnotes cite it. Every quotation in the book can be traced to one of them.

## The Pāli Texts

**The Vinaya in Pāli.** The book quotes the Mahāsaṅgīti edition of the Pāli canon, and at a few points Oldenberg's edition for the Pali Text Society. Page references are to Oldenberg's edition: "(III 128,26)" means volume III, page 128, line 26. Volume III holds the first part of the Suttavibhaṅga (the Pārājikas to the Nissaggiya Pācittiyas), and volume IV the second (the Pācittiyas onward). A footnote that writes "Vin III" or "Vin IV" means the same volumes.

**The suttas in Pāli.** These are quoted from the Mahāsaṅgīti edition and cited by collection and number, with the Pali Text Society's volume and page in brackets where the footnote gives one: "SN 35.240 (SN IV 177–178)". A collection printed in one volume (the Dhammapada, the Sutta Nipāta, the Itivuttaka) takes the page alone, "PTS p. 25", so that it is not read as a verse or sutta number.

## Translations and Studies of the Vinaya

**Brahmāli, Vibhaṅga translation.** Bhikkhu Brahmāli's English translation of the Vinaya Piṭaka, the *Theravāda Collection on Monastic Law*. It is the source of every Story and of most of the analysis in each entry. A footnote names the rule and the part of the Vibhaṅga it draws on: "Brahmāli, Vibhaṅga translation, NP 18, definitions". His endnotes to the translation are cited as part of it.

**Brahmāli, *Pātimokkha Manual*.** His *Pātimokkha Manual with Notes on Translation and Commentary*, which gives each rule's factors and his notes on its translation. After its first mention in an entry it is "the Manual". Its references to the Pāli are in the Pali Text Society form described above.

**Brahmāli, *Appendix I: Technical Terms*.** The glossary of technical terms in his translation of the Vinaya, cited by the term discussed.

**Brahmāli, *Pātimokkha* recitation translation (May 2025).** His English translation of the condensed rule as it is recited at the uposatha. Each entry's recitation line is taken from it.

**Thanissaro, *BMC1* and *BMC2*.** Ṭhānissaro Bhikkhu's *The Buddhist Monastic Code*, volume I (the Pātimokkha rules) and volume II (the Khandhaka rules). It cites the Khandhakas in the older form "Mv" (Mahāvagga) and "Cv" (Cullavagga), followed by chapter, section and paragraph: "Mv.VI.14.7".

**Ajahn Brahm, *Vinaya Notes*.** Ajahn Brahm's notes on the Pātimokkha rules. Volume 1 runs from the Pārājikas to the end of the Nissaggiya Pācittiyas, and volume 2 from the first Pācittiya onward.

**Bhikkhu Anon, *Concise BMC*.** *The Concise Buddhist Monastic Code* (version 4.2), a condensation of Ṭhānissaro's work by an author who gives no name. "Dk" in it stands for a *dukkaṭa*.

**Ñāṇatusita.** Bhikkhu Ñāṇatusita's *The Bhikkhu Pātimokkha* and *Analysis of the Bhikkhu Pātimokkha* (Buddhist Publication Society, 2014). He is consulted only on questions of translation and grammar, on the recensions of other schools, and on the etymology of technical terms. He labels the rule classes "Pr" (Pārājika), "Sd" (Saṅghādisesa) and "Pāc" (Pācittiya).

## The Class Transcripts

**Brahmāli, class transcript.** Ajahn Brahmāli taught the whole Pātimokkha, and then the Khandhakas, in a series of classes recorded between November 2011 and December 2013. I made the recordings, and they were transcribed by automatic speech recognition. They are unpublished. A reader cannot consult them, and so the book uses them only within narrow limits. A class passage is used only for a modern application of a rule, or for a view of Brahmāli's that no written source gives. It is never used to support a point the written sources already make. A footnote cites the session's number and the date it was taught: "Brahmāli, class transcript, session 027, 7 June 2012". The few sessions whose recordings carry no date are cited by their subject instead: "session 052 (Misbehaviour), undated". Where the body of an entry says Brahmāli said something "in class", this is the source.

## The Commentaries

**The Samantapāsādikā and the Kaṅkhāvitaraṇī.** These are the classical commentaries on the Vinaya and on the Pātimokkha. They enter this book only as a modern source reports them. Thanissaro calls the Samantapāsādikā "the Commentary" and the Kaṅkhāvitaraṇī "the K/Commentary"; the book follows him in the first and names the second, and his quotations keep his own names. A footnote that names a commentary also names the translator or author through whom it is cited: "the Commentary, as Thanissaro reports it". In footnotes quoting other writers, "Sp" and "VA" stand for the Samantapāsādikā, and "Kkh" for the Kaṅkhāvitaraṇī.

## Sutta Translations

The suttas are quoted in Bhikkhu Bodhi's translations of the Majjhima, Saṃyutta and Aṅguttara Nikāyas and the Sutta Nipāta, in Maurice Walshe's translation of the Dīgha Nikāya, and in Bhikkhu Suddhāso's translation of the Dhammapada. Where no translation of a passage is used, the rendering is my own, and the footnote says so.

## Measures and Money

The Vinaya measures in units whose size is no longer known, and the sources convert them differently. The book does not settle on one figure. Each conversion in an entry is given as its author's, and the main ones are set side by side here.

*Lengths.* The hardest are the *sugata* or "standard" measures, in which most maximum sizes are set. Thanissaro (*BMC1*, Appendix II, "Sugata measures"), following the Vinayamukha's suggestion of a 50 cm cubit for the Buddha, takes the standard span (*sugatavidatthi*) as 25 cm and the standard fingerbreadth as 2.08 cm. Brahmāli's appendix of technical terms (*sugata*) starts instead from the commentaries' gloss, three spans of an average man to one standard span, and from an average height of 160 cm. That gives a forearm (*hattha*) of 40 cm, a span of 20 cm and a standard span of 60 cm, though he would rather decide such questions by "broader criteria from the Vinaya—such as not being indulgent or luxurious" than by exact numbers. The Manual follows Thanissaro's 25 cm. Where the two differ, an entry may give both figures (Pc 87, Pc 89).

*Distances.* The *yojana* has no fixed length. Thanissaro reckons it at about 16 km; Brahmāli's appendix follows Rhys Davids at about 13 km; the Manual takes ten miles; Ajahn Brahm reports estimates from four and a half miles to twelve, and takes the Vinayamukha's ten miles (16 km). The figures are compared at NP 16.

*Money.* The theft rule (Pj 2) sets its threshold at a *pāda*, which in Rājagaha at the time was worth five *māsaka*. No modern equivalent is certain. Ajahn Brahm (*Vinaya Notes*, vol. 1, Pārājika 2) reports the Samantapāsādikā's warning that "the kahāpaṇa (4 pāda) of olden times is not the same as the present day kahāpaṇa of King Rudra and other kings", and finds "no logical basis" for the view, held in some Thai monasteries, that the *pāda* is the modern *baht*, a word derived from it. He and Thanissaro (*BMC1*, Pārājika 2) both report the Sub-commentary's way of fixing the value in gold, which puts the pārājika threshold at an item worth twenty rice grains' weight of gold (about 1/24 troy ounce) at current prices. Ajahn Brahm notes that the Burmese elders use this method; Thanissaro weighs an objection to it and keeps it.

## Abbreviations

| | |
|---|---|
| Pj, Sg, Ay, NP, Pc | Pārājika, Saṅghādisesa, Aniyata, Nissaggiya Pācittiya, Pācittiya, followed by the rule number |
| Pd, Sk, As | Pāṭidesanīya, Sekhiya, Adhikaraṇasamatha, followed by the rule number; not covered in this book |
| Bi | Bhikkhunī Vibhaṅga, before a class and number: a rule of the bhikkhunīs' pātimokkha |
| Kd | Khandhaka, followed by the chapter number in Brahmāli's translation |
| Mv, Cv | Mahāvagga, Cullavagga: the Khandhakas in the numbering *BMC1* and *BMC2* use |
| DN, MN, SN, AN | Dīgha, Majjhima, Saṃyutta and Aṅguttara Nikāya |
| Snp, Dhp, Iti | Sutta Nipāta, Dhammapada, Itivuttaka |
| Sp, VA | Samantapāsādikā, the Vinaya commentary |
| Kkh | Kaṅkhāvitaraṇī, the commentary on the Pātimokkha |
| PTS | the Pali Text Society's edition |
| § | a numbered section of a sutta in the translation cited |


