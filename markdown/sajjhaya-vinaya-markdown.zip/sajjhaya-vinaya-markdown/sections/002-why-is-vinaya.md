# Why Is Vinaya?

In laying down Pārājika 1, the first rule of the pātimokkha, which entails expulsion for sexual intercourse, the Buddha states ten reasons for laying down training rules (Bu Pj 1: 5.11.31):

1. for the excellence of the Community
2. for the comfort of the Community
3. for the curbing of the impudent
4. for the comfort of well-behaved bhikkhus
5. for the restraint of effluents related to the present life
6. for the prevention of effluents related to the next life
7. for the arousing of faith in the faithless
8. for the increase of the faithful
9. for the establishment of the true Dhamma
10. for the fostering of discipline.[^intro-thanissaro-tenreasons]

Thanissaro groups these into three categories: two external (the well-being of the Community itself, and the protection of the faith the laity place in it) and one internal (the restraint of the individual bhikkhu's own defilements).[^intro-thanissaro-threecategories] The grouping answers a question new students often have: is the Vinaya chiefly about *how the Community appears* to the world, or about *the inner life* of the one who keeps it? On the Buddha's stated reasons it is both. The rules keep the Community working and trusted by those who support it, and in the same act they train the mind toward the qualities that make awakening possible.

The rules were not laid down ahead of problems that had not yet arisen. In the Bhaddāli Sutta (MN 65) the Buddha explains to a reluctant bhikkhu why there are now more training rules and fewer bhikkhus reaching awakening than in the earliest days. The cause lies in the Community, not in the rules. As it grew larger and more established, with more material support and reputation, more *opportunities* for unenlightened behaviour opened up, and the rules grew in number and complexity to counter each of those as it actually arose, never to hedge against imagined ones.[^intro-thanissaro-bhaddali] The Vinaya's complexity is therefore a measure of how varied human failings can be. It is no sign that the path itself has become more demanding.

[^intro-thanissaro-tenreasons]: Thanissaro, *BMC1*, "Dhamma-Vinaya" — the ten reasons, citing the Sudinna origin story to Pj 1.
[^intro-thanissaro-threecategories]: Thanissaro, *BMC1*, "Dhamma-Vinaya" — Thanissaro's grouping of the ten reasons into two external categories and one internal category.
[^intro-thanissaro-bhaddali]: Thanissaro, *BMC1*, "Dhamma-Vinaya" — citing MN 65, the Bhaddāli Sutta, on the five conditions that create an opening for effluents as the Community grows.
