# Disrobing

The first rule of the pātimokkha opens by stating that it applies only to a bhikkhu who has not disrobed and renounced the training, and by extension so does every other rule in the code. The Vibhaṅga accordingly begins its explanation of that rule with a careful account of what does, and does not, constitute valid disrobal.

A bhikkhu who disrobes improperly remains bound by the Vinaya. If he then breaks one of the pārājika rules, for instance, he is barred from ever becoming a bhikkhu again in this lifetime. Getting the procedure of disrobal right therefore matters a great deal, and not as a technicality: so much else depends on it.

---

## Footnotes


