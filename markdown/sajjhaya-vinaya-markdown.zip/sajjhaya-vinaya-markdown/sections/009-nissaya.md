# Nissaya

*Nissaya* refers to a period of formal apprenticeship, or "dependence": every newly ordained bhikkhu must train under the guidance of an experienced bhikkhu for a minimum of five years before being considered capable of living independently.[^intro-brahmali-nissaya-five-years] It is one of the most continuously practised traditions in Buddhist monastic life, observed in some form since the Buddha's own time, and a basic structural feature of the Dhamma-Vinaya as a lived training and not only a textual one.

Nissaya is of two types: *upajjhāya*, dependence on one's preceptor, and *ācariya*, dependence on one's teacher more generally, close enough in character for "mentor" to cover both.[^intro-brahmali-nissaya-twotypes] The Mahāvagga sets out a long list of qualifications a bhikkhu must meet before he may act as a preceptor; the Samantapāsādikā further distinguishes "ideal" from merely "minimal" qualifications for the role.[^intro-thanissaro-preceptor-qualifications] The candidate formally requests dependence from his preceptor before, and usually as part of, the ordination ceremony itself.

## Duties

The Mahāvagga frames the relationship between pupil and mentor as akin to that between father and son, and sets out the reciprocal duties of each in some detail.[^intro-brahmali-nissaya-fatherson] The duties are best read in Khandhaka 1 itself. The text shows how this one relationship is meant to cultivate sensitivity to another person's needs, and it gives a great deal of fine, concrete detail on mindfulness in action: how to fold a robe, how to clean a dwelling, and so on. Such detail can read as mundane until one notices how much of the training is built from this kind of attention to small things done well. The relationship runs in both directions. A student does not merely defer to his preceptor as a superior: he should stop one whose speech borders on an offence, and help one who has grown discontented or anxious, holds a wrong view, or has committed a serious offence to find his way back.[^intro-brahmali-nissaya-mutual]

[^intro-brahmali-nissaya-five-years]: Brahmāli, *Introduction to the Khandhakas, part I* — citing Kd 1 on the minimum five-year (monks) / two-year (nuns) dependence period.
[^intro-brahmali-nissaya-twotypes]: Brahmāli, *Introduction to the Khandhakas, part I* — *upajjhāya* and *ācariya* as the two types of nissaya.
[^intro-thanissaro-preceptor-qualifications]: Thanissaro, *BMC1*, "Nissaya" — on the Mahāvagga's preceptor qualifications and the Samantapāsādikā's "ideal"/"minimal" distinction.
[^intro-brahmali-nissaya-fatherson]: Brahmāli, *Introduction to the Khandhakas, part I* — citing Kd 1:25.6.2–25.6.3 on the father/son framing of the teacher-student relationship.
[^intro-brahmali-nissaya-mutual]: Brahmāli, *Introduction to the Khandhakas, part I* — citing Kd 1:25.10.3 and Kd 1:25.20.1–25.22.4 on the reciprocal, two-directional duties between preceptor and student.
