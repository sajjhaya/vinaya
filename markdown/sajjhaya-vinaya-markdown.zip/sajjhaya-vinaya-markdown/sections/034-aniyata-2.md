# Aniyata 2

## Story (Vatthu)

At one time the Buddha was staying at Sāvatthī in the Jeta Grove, Anāthapiṇḍika's Monastery. At this time Venerable Udāyī heard that the Buddha had prohibited sitting alone with a woman on a private and concealed seat suitable for the deed, and so instead he sat down in private alone with the same girl. When they were able, they just chatted; otherwise he gave her a teaching.

A second time Visākhā had been invited to that family. When she arrived, she saw Udāyī sitting in private alone with the same girl, and she said to him, "Venerable, it's not appropriate for you to sit down in private alone with a woman. You may not be aiming at that act, but it's hard to convince people with little confidence." But Udāyī did not listen.

After leaving, Visākhā told the monks what had happened. The monks of few desires complained and criticised him: "How could Venerable Udāyī sit down in private alone with a woman?" They told the Buddha, who had the Saṅgha gathered and questioned Udāyī: "Is it true, Udāyī, that you did this?" "It's true, sir." The Buddha rebuked him and laid down the rule.[^ay2-brahmali-story]

**Synopsis** — Told that a concealed seat is forbidden, Udāyī sits with the same girl in private on an open one; Visākhā warns him again and he does not listen, and the Buddha extends the procedure to a seat private enough for indecent speech.

## Translation (Mātikā)

**Brahmāli**

*Full Vibhaṅga translation* — "Although a seat is not concealed, nor suitable for the deed, it may be suitable for speaking indecently to a woman. If a monk sits down on such a seat in private alone with a woman, and a trustworthy female lay follower sees him and accuses him of an offense entailing suspension or an offense entailing confession, then, if he admits to the sitting, he is to be dealt with according to one of these two or according to what that trustworthy female lay follower has said. This rule too is undetermined."[^ay2-brahmali-rule]

*Condensed recitation translation* — "It may be that a bhikkhu sits alone in private with a woman and is seen by a trustworthy female lay disciple. If she accuses him of a saṅghādisesa or a pācittiya, and if he admits that charge, he should be dealt with accordingly."[^ay2-brahmali-recitation]

**Thanissaro** (*BMC1*)

"In case a seat is not sufficiently secluded to lend itself (to sexual intercourse) but sufficiently so to address lewd words to a woman, should any bhikkhu sit in private, alone with a woman on such a seat, so that a female lay follower whose word can be trusted, having seen (them), might describe it as constituting either of two cases—entailing communal meetings or confession—then the bhikkhu, acknowledging having sat (there), may be dealt with in line with either of the two cases—entailing communal meetings or confession—or he may be dealt with in line with whichever case the female lay follower whose word can be trusted described. This case too is indefinite."[^ay2-thanissaro-rule]

**Brahm** (*Vinaya Notes*, vol. 1)

"In case the seat is not sufficiently screened to be suitable (for sexual intercourse), but still convenient to address lewd words to a woman, then should any monk sit in private in such a seat, just the monk and her, so that a trustworthy female lay follower having seen (them), might describe it as constituting either of two cases: initial and subsequent meeting of the community or confession, (then) the monk acknowledging having been seated may be dealt with for either of the two cases: initial and subsequent meetings of the community or confession -- or he may be dealt with for whichever (case) the female lay follower described. This case too is undetermined."[^ay2-brahm-rule]

**Ñāṇatusita**

"Now, even if the seat is neither concealed nor sufficiently fit for doing it, but is sufficient for speaking suggestively to a woman with depraved words: if any bhikkhu should take a seat together with a woman on such a seat—one [man] with one [woman], privately—[and then if] a female lay-follower whose words can be trusted having seen that, should speak in accordance with one of two cases: in accordance with [a case] involving the community in the beginning and in the rest, or in accordance with expiation, [then] the bhikkhu admitting the sitting down is to be made to do in accordance with one of two cases: in accordance with [a case] involving the community in the beginning and in the rest, or in accordance with expiation, or in accordance with whatever that female lay-follower whose words can be trusted should say, in accordance with that the bhikkhu is to be made to do, this too is an uncertain case."[^ay2-nyanatusita]

The renderings divide as at Aniyata 1, where the recitation's "if he admits that charge" is discussed. This rule's own difference is in the first sentence, which the recitation drops: the seat is not concealed and not suitable for the deed, yet suitable "for speaking indecently" (Brahmāli), "to address lewd words" (Thanissaro, Ajahn Brahm), "for speaking suggestively … with depraved words" (Ñāṇatusita). The recitation keeps "in private" and leaves the reader to supply the rest from the word-analysis.

## Explanation (Padabhājanīya)

The rule protects lay confidence where a monk sits alone with a woman even in the open, for what troubled Visākhā was never only the concealment. Udāyī moved from a concealed seat to an open one and sat with the same girl. Visākhā's second warning drops the words "on a concealed seat suitable for the deed": "it's not appropriate for you to sit down in private alone with a woman."[^ay2-brahmali-story] The second rule follows her.

The procedure is Aniyata 1's in every respect: the trustworthy witness, the hearing she can require without leave, the resolution by what the monk admits, the later guidelines, and the dispute over a monk who admits nothing.[^ay2-manual-asaniyata1] [^ay2-thanissaro-otherwisesame] Two things differ, the circumstance and so the range of offences.

**Circumstance**

The seat is not concealed by a wall, a screen, a door or anything else, and sexual intercourse would not be possible there, though one could speak indecently to a woman. It is private to the eye and to the ear as before.[^ay2-brahmali-definitions] Thanissaro's examples are an open-air meeting hall, or a place in the open, in sight of others but too far for them to see a wink or hear a normal voice.[^ay2-thanissaro-difference] Ajahn Brahm's examples are modern, and they show how to read "private" today: a bench in a deserted park, a room with the doors wide open, a car parked by day in a deserted street.[^ay2-brahm-whichoffences] The woman, accordingly, is one able to tell decent speech from indecent, as under Sg 3, where the offence lies in what she hears.[^ay2-brahmali-definitions] [^ay2-manual-womanasSg3]

The penalty is a saṅghādisesa or a pācittiya, and a pārājika drops out. Which saṅghādisesas, the sources list differently. Thanissaro names Sg 3, Sg 4 and Pc 45, and calls the place inconvenient for Pj 1, Sg 1–2 and Pc 44; Ajahn Brahm names Sg 2, 3 and 4 and Pc 45 and leaves the list open.[^ay2-thanissaro-difference] [^ay2-brahm-whichoffences] The Vibhaṅga's own series settles the point about Sg 2: its charges here are of physical contact and of indecent speech, seated or lying down.[^ay2-brahmali-resolution] Thanissaro's list, then, is best read as his illustration of what such a place most favours, not as a limit.

Udāyī's second seat was in the open and the girl was the same. The second rule teaches what the first had already meant: whether he is in a closed room or out in the open, a monk sitting with a woman where no one can see or hear them is in the situation Visākhā warned him against.

## Resolution Grid (Pariccheda)

As at Aniyata 1, with a saṅghādisesa as the heaviest outcome:[^ay2-brahmali-permutations]

- He admits the offence, whether or not he admits going there or sitting: dealt with for the offence.
- He admits sitting, but not the offence: dealt with for the sitting.
- He admits neither sitting nor the offence, whether or not he admits going there: not dealt with.

## Exemptions (Anāpatti)

The rule carries no non-offence clause; as at Aniyata 1, a monk who admits only going there, or nothing the rule describes, "is not to be dealt with."[^ay2-brahmali-permutations]

## Related Offences

- **Aniyata 1** — the same procedure for a concealed seat, where it is set out in full.
- **Sg 2, Sg 3, Sg 4** — physical contact, indecent speech, and speaking in praise of sexual service, the saṅghādisesas such a seat affords.
- **Pc 45** — sitting in private alone with a woman, the pācittiya most often beneath a charge under this rule.

## Related Suttas

- **AN 5.55** — the verse: "One might talk with a murderous foe, / one might talk with an evil spirit, / one might even approach a viper / whose bite means certain death; / but with a woman, one to one, / one should never talk"; the private talk the second rule covers.[^ay2-an555]
- **SN 35.127** — that lust can arise even toward women "old enough to be one's mother", "of an age to be one's sister", "young enough to be one's daughter", so that no woman's age, nor the regard due to her as mother, sister or daughter, makes a private seat safe.[^ay2-sn35127]
- **SN 47.6** — "Māra will gain access to those who stray outside their own resort into the domain of others"; an open seat, in private, is still outside a monk's resort.[^ay2-sn476]

## Threads

Venerable Udāyī (*Characters of the Vinaya*); Guarding the Senses (*Themes*); How an Accusation Is Heard (*Themes*)

---

## A note on sourcing

The Story is from Brahmāli's Vibhaṅga translation alone. The Explanation rests on that translation, Brahmāli's *Pātimokkha Manual*, Thanissaro's *BMC1* and Ajahn Brahm's *Vinaya Notes*, with Ñāṇatusita's *Analysis* for his rendering, and otherwise on Aniyata 1. The class treats the two rules together and raised no question particular to this one; it is not cited. The suttas are quoted from Bhikkhu Bodhi's translations.

---

[^ay2-brahmali-story]: Brahmāli, Vibhaṅga translation, Ay 2, origin story: "At this time Venerable Udāyī heard that the Buddha had prohibited sitting alone with a woman on a private and concealed seat suitable for the deed, and so instead he sat down in private alone with the same girl"; "Venerable, it's not appropriate for you to sit down in private alone with a woman. You may not be aiming at that act, but it's hard to convince people with little confidence."
[^ay2-brahmali-rule]: Brahmāli, Vibhaṅga translation, Ay 2, final ruling.
[^ay2-brahmali-recitation]: Brahmāli, *Pātimokkha* recitation translation (May 2025), Aniyata 2.
[^ay2-thanissaro-rule]: Thanissaro, *BMC1*, Ay 2, the rule.
[^ay2-brahm-rule]: Ajahn Brahm, *Vinaya Notes*, vol. 1, Aniyata 2, the rule translation he gives "for the sake of consistency".
[^ay2-nyanatusita]: Ñāṇatusita, *Analysis of the Bhikkhu Pātimokkha*, "Aniy 2: Dutiya-aniyatasikkhāpadaṃ", printed pp. 101–102, "The second uncertain training precept".
[^ay2-manual-asaniyata1]: Brahmāli, *Pātimokkha Manual*, Aniyata 2, its factors: "'A woman' as in Sg.3 (factor 4 only); 'sits' + 'in private' + 'a trustworthy female lay disciple' + 'the bhikkhu admits the charge' + 'he should be dealt with accordingly' as in aniy.1."
[^ay2-thanissaro-otherwisesame]: Thanissaro, *BMC1*, Ay 2: "Otherwise, all explanations for this rule are the same as for the preceding rule."
[^ay2-brahmali-definitions]: Brahmāli, Vibhaṅga translation, Ay 2, definitions: "Although a seat is not concealed: it is not concealed by a wall, a screen, a door, a cloth screen, a tree, a pillar, a grain container, or anything else. Nor suitable for the deed: one is not able to have sexual intercourse. It may be suitable for speaking indecently to a woman: one is able to speak indecently to a woman"; "A woman: a human female, not a female spirit, not a female ghost, not a female animal. She understands and is capable of discerning good and bad speech, what is decent and what is indecent."
[^ay2-thanissaro-difference]: Thanissaro, *BMC1*, Ay 2: "This rule differs from the preceding one mainly in the type of seat it describes—private to the eye and private to the ear, but not secluded. Examples would be an open-air meeting hall or a place out in the open in sight of other people but far enough away from them so that they could not see one wink, etc., or hear what one is saying in a normal voice. Such a place, although inconvenient for committing Pr 1, Sg 1 & 2, or Pc 44, would be convenient for committing Sg 3 & 4 or Pc 45."
[^ay2-brahm-whichoffences]: Ajahn Brahm, *Vinaya Notes*, vol. 1, Aniyata 2: "For example, a bench in a deserted park, a room with the doors wide open or a car parked during the day in a deserted street, would all be private places not screened"; "the accusations of the trustworthy female lay follower would probably concern either saṅghādisesa 2, 3 or 4 or pācittiya 45, though there is no reason to exclude the possibility of accusations concerning other rules also."
[^ay2-manual-womanasSg3]: Brahmāli, *Pātimokkha Manual*, Aniyata 2: "'A woman' as in Sg.3 (factor 4 only)."
[^ay2-brahmali-resolution]: Brahmāli, Vibhaṅga translation, Ay 2, definitions: "If she accuses him like this: 'I've seen you seated, making physical contact with a woman,' and he admits to that, then he is to be dealt with for the offense"; "If she accuses him like this: 'I've heard you speaking indecently to a woman while seated,' and he admits to that, then he is to be dealt with for the offense"; "Undetermined: not determined. It is either an offense entailing suspension or an offense entailing confession."
[^ay2-brahmali-permutations]: Brahmāli, Vibhaṅga translation, Ay 2, permutations: the same eight as Aniyata 1, beginning "If he admits to going, and he admits to sitting, and he admits to an offense, he is to be dealt with for the offense".
[^ay2-an555]: AN 5.55, *Mother and Son* (AN III 67–69), tr. Bhikkhu Bodhi, the closing verses.
[^ay2-sn35127]: SN 35.127, *Bhāradvāja* (SN IV 111), Bhikkhu Bodhi's translation: "Sometimes states of lust arise even towards women old enough to be one's mother; sometimes they arise towards women of an age to be one's sister; sometimes they arise towards women young enough to be one's daughter."
[^ay2-sn476]: SN 47.6, *The Hawk* (*Sakuṇagghisutta*) (SN V 146–148), tr. Bhikkhu Bodhi: "Māra will gain access to those who stray outside their own resort into the domain of others; Māra will get a hold on them."
