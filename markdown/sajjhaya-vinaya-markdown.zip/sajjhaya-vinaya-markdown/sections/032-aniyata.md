# Aniyata

The two aniyata ("undetermined" or "indefinite") rules are unlike anything else in the pātimokkha. They fix no penalty of their own. They set out how a particular accusation is to be judged: a trustworthy female lay follower reports having seen a bhikkhu sitting in private with a woman, and the penalty is not settled in advance. On the Vibhaṅga's reading it falls as a pārājika, a saṅghādisesa or a pācittiya, or not at all, according to what the bhikkhu himself admits; the second rule names only the last two, and the **Aniyata 1** entry takes up the further clause both rules carry, "or according to what that trustworthy female lay follower has said". The two are also unique to the bhikkhu pātimokkha, for there is no aniyata class for bhikkhunīs.[^ayoverview-unique] Both have the same origin figure, Venerable Udāyī, and the same lay witness, Visākhā Migāramātā.

The two aniyatas, **Pc 30**, **Pc 44** and **Pc 45** all concern a bhikkhu sitting in private with a woman. "In private" means the same in all five: no one else can see them wink, raise an eyebrow or nod, and no one can hear ordinary speech.[^ayoverview-private] They differ in the seat, in how many women there are and who they are, and in whose presence removes the offence.

| Rule | The seat | With | Presence that exempts | Outcome |
|---|---|---|---|---|
| Aniyata 1 | concealed, suitable for the deed | one woman, he alone | none stated | a laywoman's charge: pārājika, saṅghādisesa or pācittiya |
| Aniyata 2 | not concealed, suitable for indecent speech | one woman, he alone | none stated | a laywoman's charge: saṅghādisesa or pācittiya |
| Pc 44 | concealed | one woman or more | a man who understands | pācittiya |
| Pc 45 | not concealed | one woman, he alone | a companion who understands, man or woman, as the sources read it | pācittiya |
| Pc 30 | not concealed | one bhikkhunī, he alone | a companion who understands | pācittiya |

Aniyata 2's seat is the seat of Pc 45 and Pc 30, and Pc 30 is, but for one rare case, Pc 45 with the woman narrowed to a bhikkhunī. Each entry's Related Offences gives the detail.[^ayoverview-grid]

---

### Footnotes (Aniyata — Class Overview)

[^ayoverview-unique]: Bhikkhu Anon, *Concise BMC*, Aniyata, class introduction — "The aniyatas are unique among the Bhikkhu Patimokkha rules in that there is no corresponding class of aniyata rules in the Bhikkhunī Patimokkha."
[^ayoverview-private]: Brahmāli, Vibhaṅga translation, Aniyata 1, definitions, "*In private*" (privacy to the eye and to the ear); the same definition stands at Aniyata 2, Pc 30, Pc 44 and Pc 45.
[^ayoverview-grid]: Brahmāli, Vibhaṅga translation, Aniyata 1, Aniyata 2, Pc 30, Pc 44 and Pc 45, rules and non-offence clauses; on Pc 45's companion, which the Vibhaṅga prints as "a male companion who understands" and every source reads more widely, see that entry; on Pc 30, Thanissaro, *BMC1*, Pc 30: "Except for one rare case—a bhikkhunī who does not know what is lewd and not lewd—this rule is completely subsumed under Pc 45."
